package businessLayer;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import dataLayer.DataLayer;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

/**
 * @author Tanzim Ahmed Sagar
 * @version 1.0
 */
public class SagarTanzimAhmedLab02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DataLayer dataLayer = new DataLayer();
        PrintLayout printLayout = new PrintLayout();
        InputStream propertiseFile = null;
        ResultSet queryData = null;
        ResultSetMetaData queryResultMetaData = null;
        try {
            //parsing database.propertise
            propertiseFile = Files.newInputStream(Paths.get("src/database.properties"));
        } catch (IOException ex) {
            System.err.print("Couldn't parse properties file!");
        }
        //setting credentials
        dataLayer.setCredentials(propertiseFile);
        //creating Connection
        dataLayer.connectDatabase();
        try {
            //Getting Result
            queryData = dataLayer.getResultSet("SELECT * FROM recipients");
        } catch (SQLException ex) {
            System.err.print("Couldn't get ResultSet for 1st time!");
        }
        try {
            //Getting Metadata of the result
            queryResultMetaData = dataLayer.provideMetaData(queryData);
        } catch (SQLException ex) {
            System.err.print("Couldn't get Metadata for the ResultSet!");
        }
        //Printing Query Table for first time!
        printLayout.printTable(queryResultMetaData, queryData, "recipients Table of Ontario Database:\n");
        //Printing Query Attribute Table for first time!
        printLayout.printAttriTable(queryResultMetaData);
        //inserting a new row in the table and printing the contents
        boolean mthd = dataLayer.editDatabase("INSERT INTO recipients (AwardID, Name, Year, City, Catagory) VALUES (66, Ahmed; Tanzim, 2017, Ottawa, Programming);");
        System.out.println(mthd);
        try {
            //Generating new ResultSet
            queryData = dataLayer.getResultSet("SELECT * FROM recipients");
        } catch (SQLException ex) {
            System.err.print("Couldn't get ResultSet for 2nd time!");
        }
    }
    
}